=== Team Member Slider===
Contributors: xgenious
Donate link: 
Tags: 	agency, company, crew, employee, Meet the team, members, showcase, squad, staff, team, team showcase, team sliders, visual composer, workers
Requires at least: 3.3
Tested up to: 4.9.5
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Team Member Slider is a modern Plugin. It�s have 5 styles with huge option. You can use this Team Slider on your website easily.

== Description ==
Display Team member slider anywhere in your wordpress site using Team member Slider plugin shortcodes.
<br/>
<strong>CHECK TEAM MEMBER[FREE] DEMOS</strong> 
<a href="http://plugin.devrobin.com/team-shortcode/team-slider/">Team Member Slider Demo</a>

<br/>
<strong>TEAM MEMBER SLIDER Pro Plugin[PAID]</strong><br/>
  <a href="https://codecanyon.net/item/team-slider-team-member-showcase-short-code-for-wordpress/21585296">Pro Version Demo</a> (it give a pro version of plugin file.)
<br/>


<strong>AWESOME FEATURES</strong>
<ul>
<li> Add Team member slider using shortcode as  your requirements</li>
<li> 5 unique design</li>
<li>Unlimited color options</li>
<li>Easy to customize with plugin Options</li>
<li>fully responsive</li>
<li>Cross browser support</li>
</ul>

<strong>TEAM MEMBER SLIDER WIDGET PRO[PAID] FEATURES</strong>
<br/><br/>
<ul>
<li>15 unique design team member slider with team member details</li>
<li>15 Grid team member with team member details </li>
<li>2 design full row team member style</li>
<li>Easy to customize with the plugin options panel</li>
<li>Unlimited Color Changing options</li>
<li>Responsive Design</li>
<li>Fully Customizable</li>
<li>All Browser Supported</li>
<li>Compatible latest version WordPress</li>
<li>Cross browser support</li>
<li>Clean Coding, W3c Validate</li>
<li>24/7 First Support</li>
<li>  Step by Step Well Documented</li>
</ul>



== Installation ==

1. Upload the plugin files to the /wp-content/plugins/teams-slider-shortcode-pack directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Team Slider option and here you see options change the setting as per your need. or leave this and just copy thes shortcode given here it will take default settings.

4. To embed the Team Member Slider in a page or post, use the default shortcode: [xgenious_team_slider_01]
5. ONLINE DOCUMENTATION :- <a href="http://plugin.devrobin.com/team-shortcode/docs/">Click Here</a>

== Frequently asked questions ==

= How do I get the team member slider widget to show up? =

 Use the shortcode: [xgenious_team_slider_01 ]�and the team member slider widget will appear in your post or page. 

= How do I modify team member slider plugin shortcode ? =
In admin menu you see Team SLider menu. go here and modify using plugin option.

= Something Else? =
If you are having any other issues, please post in the Support Forum and I will respond as soon as possible.

== Screenshots ==

. screenshot-01.jpg
. screenshot-02.jpg
. screenshot-03.jpg
. screenshot-04.jpg
. screenshot-05.jpg

== Changelog ==

1.0 � (May 09, 2018)
First release. 

