<div id="crp-spinner-background">
</div>

<div id="crp-spinner" class="crp-loader crp-loader-large crp-loader-violet crp-loader-delayed">
</div>