<?php

?>

<p> Here goes Help section</p>